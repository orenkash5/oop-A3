package utils.generators;

public interface Generator {
    public int generate(int value);
}
