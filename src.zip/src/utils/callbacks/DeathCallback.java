package utils.callbacks;

public interface DeathCallback {
    void onDeath();
}
