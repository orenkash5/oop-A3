package Tests;


import model.tiles.Empty;
import model.tiles.Wall;
import model.tiles.units.enemies.Enemy;
import model.tiles.units.enemies.LannisterSolider;
import model.tiles.units.players.*;
import org.junit.Test;
import utils.Position;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class PlayerTest {

    @Test
    public void testWarriorLevelUp() {
        JonSnow jonSnow = new JonSnow();
        jonSnow.initialize(new Position(0, 0));
        int oldAttack = jonSnow.getAttackDamage();
        int oldDefense = jonSnow.getDefensePoints();
        int oldHealth = jonSnow.getHealth().getCapacity();
        jonSnow.addExperience(50);
        assertEquals(jonSnow.getLevel(), 2); // Player should level up
        assertEquals(jonSnow.getAttackDamage(), oldAttack + 4); // Attack should increase
        assertEquals(jonSnow.getDefensePoints(), oldDefense + 2); // Defense should increase
        assertEquals(jonSnow.getHealth().getCapacity(), oldHealth + 10); // Health should increase
    }

    @Test
    public void testMageLevelUp() {
        Melisandre melisandre = new Melisandre();
        melisandre.initialize(new Position(0, 0));
        int oldManaPool = melisandre.getManaPool();
        int oldMana = melisandre.getCurrentMana();
        int oldSpellPower = melisandre.getSpellPower();
        melisandre.addExperience(50);
        assertEquals(melisandre.getLevel(), 2); // Player should level up
        assertEquals(melisandre.getManaPool(), oldManaPool + 25*2);
        assertEquals(melisandre.getCurrentMana(), Math.min(oldMana+melisandre.getManaPool()/4, melisandre.getManaPool()));
        assertEquals(melisandre.getSpellPower(), oldSpellPower + 10*2);
    }

    @Test
    public void testRogueLevelUp() {
        AryaStark aryaStark = new AryaStark();
        aryaStark.initialize(new Position(0, 0));
        int oldEnergy = aryaStark.getCurrentEnergy();
        int oldAttack = aryaStark.getAttackDamage();
        aryaStark.addExperience(50);
        assertEquals(aryaStark.getLevel(), 2); // Player should level up
        assertEquals(aryaStark.getCurrentEnergy(), 100); // Energy should increase
        assertEquals(aryaStark.getAttackDamage(), oldAttack + 3*2); // Attack should increase
    }

    @Test
    public void testPlayerInteractionWithWall() {
        JonSnow jonSnow = new JonSnow();
        jonSnow.initialize(new Position(0, 0));
        Wall wall = new Wall();
        wall.initialize(new Position(0, 1));
        jonSnow.interact(wall);
        assertEquals(jonSnow.getPosition(), new Position(0, 0)); // Player should not move
    }
    @Test
    public void testPlayerInteractionWithEmptyTile() {
        JonSnow jonSnow = new JonSnow();
        jonSnow.initialize(new Position(0, 0));
        Empty empty = new Empty();
        empty.initialize(new Position(0, 1));
        jonSnow.interact(empty);
        assertEquals(jonSnow.getPosition(), new Position(0, 1)); // Player should move to empty tile
    }
    @Test
    public void testPlayerInteractionWithEnemy() {
        JonSnow jonSnow = new JonSnow();
        jonSnow.initialize(new Position(0, 0));
        LannisterSolider enemy = new LannisterSolider();
        enemy.initialize(new Position(0, 1));
        jonSnow.interact(enemy);
        assertTrue(enemy.getHealth().getCurrent() <= enemy.getHealth().getCapacity()); // Enemy should take damage
    }
    @Test
    public void testJonSnowSpecialAbility() {
        JonSnow jonSnow = new JonSnow();
        jonSnow.initialize(new Position(0, 0));
        while (jonSnow.getRemainingCooldown()>0){
            jonSnow.onGameTick();
        }
        List<Enemy> enemies = new ArrayList<>();
        LannisterSolider enemy1 = new LannisterSolider();
        enemy1.initialize(new Position(0, 1));
        enemies.add(enemy1);
        jonSnow.specialAbility(enemies);
        assertTrue(enemy1.getHealth().getCurrent() < enemy1.getHealth().getCapacity()); // Enemy should take damage from special ability
    }


    @Test
    public void testMelisandreSpecialAbility() {
        Melisandre melisandre = new Melisandre();
        melisandre.initialize(new Position(0, 0));
        while (melisandre.getCurrentMana()<melisandre.getManaCost()){
            melisandre.onGameTick();
        }
        List<Enemy> enemies = new ArrayList<>();
        LannisterSolider enemy1 = new LannisterSolider();
        enemy1.initialize(new Position(0, 1));
        enemies.add(enemy1);
        melisandre.specialAbility(enemies);
        assertTrue(enemy1.getHealth().getCurrent() < enemy1.getHealth().getCapacity());
    }


    @Test
    public void testAryaStarkSpecialAbility() {
        AryaStark aryaStark = new AryaStark();
        aryaStark.initialize(new Position(0, 0));
        while (aryaStark.getCurrentEnergy()<aryaStark.getCost()){
            aryaStark.onGameTick();
        }
        List<Enemy> enemies = new ArrayList<>();
        LannisterSolider enemy1 = new LannisterSolider();
        enemy1.initialize(new Position(0, 1));
        enemies.add(enemy1);
        aryaStark.specialAbility(enemies);
        assertTrue(enemy1.getHealth().getCurrent() < enemy1.getHealth().getCapacity());

    }


}
