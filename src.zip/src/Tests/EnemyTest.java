package Tests;

import model.tiles.Empty;
import model.tiles.Wall;
import model.tiles.units.enemies.Enemy;
import model.tiles.units.enemies.LannisterSolider;
import model.tiles.units.enemies.Trap;
import model.tiles.units.players.JonSnow;
import org.junit.Test;
import utils.Position;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class EnemyTest {
    @Test
    public void EnemyTest1(){
        LannisterSolider enemy = new LannisterSolider();
        enemy.initialize(new Position(0,0));
        Empty empty = new Empty();
        Position position = new Position(0,1);
        empty.initialize(position);
        enemy.interact(empty);
        assertEquals(enemy.getPosition(), position);
    }
    @Test
    public void testEnemyInteractionWithWall() {
        LannisterSolider enemy = new LannisterSolider();
        enemy.initialize(new Position(0, 0));
        Position position = enemy.getPosition();
        Wall wall = new Wall();
        wall.initialize(new Position(0, 1));
        enemy.interact(wall);
        assertEquals(enemy.getPosition(), position); // Enemy should not move
    }
    @Test
    public void testEnemyInteractionWithAnotherEnemy() {
        LannisterSolider enemy1 = new LannisterSolider();
        enemy1.initialize(new Position(0, 0));
        Position position1 = enemy1.getPosition();
        LannisterSolider enemy2 = new LannisterSolider();
        enemy2.initialize(new Position(0, 1));
        Position position2 = enemy2.getPosition();
        enemy1.interact(enemy2);
        assertEquals(enemy1.getPosition(), position1); // Enemy1 should not move
        assertEquals(enemy2.getPosition(), position2); // Enemy2 should not move
    }

}
