package view;

public class CLI  extends View {
    public void display(String message) {
        System.out.println(message);
    }
}
