package control;

public class Program {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}
