package model.tiles.units.enemies;

public class BonusTrap extends Trap{
    public BonusTrap(){
        super('B', "Bonus Trap", 1, 1, 1, 250, 1, 5);
    }
}
