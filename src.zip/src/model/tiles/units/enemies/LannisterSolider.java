package model.tiles.units.enemies;

public class LannisterSolider extends Monster{
    public LannisterSolider(){
        super('s', "Lannister Solider", 80, 8, 3, 25, 3);
    }
}
