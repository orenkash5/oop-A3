package model.tiles.units.enemies;

public class BearWright extends Monster{
    public BearWright(){
        super('b', "BearWright", 100, 75, 30, 250, 4);
    }
}
