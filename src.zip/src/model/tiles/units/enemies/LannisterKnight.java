package model.tiles.units.enemies;

public class LannisterKnight extends Monster{
    public LannisterKnight(){
        super('k', "Lannister Knight", 200, 14, 8, 50, 4);
    }
}
