package model.tiles.units.enemies;

public class Wright extends Monster{
    public Wright(){
        super('z', "Wright", 600, 30, 15, 100, 3);
    }
}
