package model.tiles.units.enemies;

public class QueenCersei extends Monster{
    public QueenCersei(){
        super('C', "Queen Cersei", 100, 10, 10, 1000, 1);
    }
}
