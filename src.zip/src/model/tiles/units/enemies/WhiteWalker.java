package model.tiles.units.enemies;

public class WhiteWalker extends Monster{
    public WhiteWalker(){
        super('w', "White Walker", 2000, 150, 50, 1000, 6);
    }
}
