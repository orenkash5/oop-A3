package model.tiles.units.enemies;

public class QueensTrap extends Trap{
    public QueensTrap(){
        super('Q', "Queen's Trap", 250, 50, 10, 100, 3, 7);
    }
}
