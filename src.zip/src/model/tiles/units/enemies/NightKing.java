package model.tiles.units.enemies;

public class NightKing extends Monster{
    public NightKing(){
        super('K', "Night’s King ", 5000, 300, 150, 5000, 8);
    }
}
