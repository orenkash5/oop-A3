package model.tiles.units.players;

public class Warrior extends Player{

    protected int abilityCooldown;
    protected int remainingCooldown;

    public Warrior(String name, int hitPoints, int attack, int defense, int abilityCooldown){
        super(name, hitPoints, attack, defense);
        this.abilityCooldown = abilityCooldown;
        this.remainingCooldown = abilityCooldown;
    }
    public void levelUp(){
        this.experience -= levelRequirement();
        this.level++;
        this.remainingCooldown = 0;
        this.health.increaseMax(5*this.level);
        this.attack = this.attack + 2*this.level;
        this.defense = this.defense + this.level;
    }

    public void gameTick() {
        this.remainingCooldown=Math.max(remainingCooldown-1, 0);
    }

    public void onAbilityCastAttempt() {
        if (this.remainingCooldown == 0) {
            this.remainingCooldown = this.abilityCooldown;
            this.health.healAmount(this.health.getCurrent() + 10 * this.defense);
            // continue function
        }
    }
}
