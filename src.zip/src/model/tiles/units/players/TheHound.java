package model.tiles.units.players;

public class TheHound extends Warrior{
    public TheHound() {
        super("The Hound",400, 20, 6, 5);
    }
}
