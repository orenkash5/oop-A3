package model.tiles.units.players;

public class Bronn extends Rogue{
    public Bronn(){
        super("Bronn", 250, 35, 3, 50);
    }
}
