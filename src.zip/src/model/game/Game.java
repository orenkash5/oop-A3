package model.game;

public class Game {

}
