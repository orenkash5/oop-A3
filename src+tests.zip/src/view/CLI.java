package view;

import model.game.Board;
import model.tiles.units.players.Player;
import model.tiles.units.players.Warrior;

public class CLI  extends View {
    public void display(String message) {
        System.out.println(message);
    }

    public void displayBoard(Board board) {
        this.display(board.toString());
    }
    public void displayStats(Board board) {
        Player player = board.getPlayer();
        this.display(player.toString() +"\t" +  "Health: " + player.getHealth().getCurrent() + "\t"+"Attack: " + player.getAttackDamage() + "\t" + "Defense:  "+player.getDefensePoints() +"\t"+ "Level: " + player.getLevel()  + "\t" + "Experience: " + player. getExperience());
    }
    public void displayCombatInfo(Board board) {
        Player player = board.getPlayer();
        //switch case for each character without casting for the information
        //if(player instanceof Warrior)
            this.display("Experience: " + player.getExperience() + "\t" + "Cooldown: " + (player.getCooldown());

    }
}
