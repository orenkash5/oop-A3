package utils.callbacks;

public interface MessageCallback {
    void send(String message);
}
