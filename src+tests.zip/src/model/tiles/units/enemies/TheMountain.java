package model.tiles.units.enemies;

public class TheMountain extends Monster{
    public TheMountain(){
        super('M', "The Mountain", 1000, 60, 25, 500, 6);
    }
}
