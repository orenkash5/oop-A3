package model.tiles.units.enemies;

public class QueensGuard extends Monster{
    public QueensGuard(){
        super('q', "Queen's Guard", 400, 20, 15, 100, 5);
    }
}
