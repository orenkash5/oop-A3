package model.tiles.units.enemies;

public class GiantWright extends Monster{
    public GiantWright(){
        super('g', "GiantWright", 1500, 100, 40, 500, 5);
    }
}
