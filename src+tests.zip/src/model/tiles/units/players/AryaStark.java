package model.tiles.units.players;

public class AryaStark extends Rogue{
    public AryaStark(){
        super("Arya Stark", 150, 40, 2, 20);
    }
}
