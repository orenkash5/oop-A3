package model.tiles.units.players;

public class ThorosOfMyr extends Mage{
    public ThorosOfMyr(){
        super("Thoros of Myr", 250, 25, 4, 150, 20, 20, 3, 4);
    }
}
