package model.tiles.units.players;

public class Melisandre extends Mage{
    public Melisandre(){
        super("Melisandre", 100, 5, 1, 300, 30, 15, 5, 6);
    }
}
