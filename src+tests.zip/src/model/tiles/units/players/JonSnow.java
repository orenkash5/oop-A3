package model.tiles.units.players;

public class JonSnow extends Warrior{
    public JonSnow() {
        super("Jon Snow",300, 30, 4, 3);
    }
}
